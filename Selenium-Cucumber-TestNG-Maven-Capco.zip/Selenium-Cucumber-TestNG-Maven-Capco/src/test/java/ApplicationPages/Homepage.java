package ApplicationPages;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.testng.Assert;

import WebConnector.webconnector;
import static WebConnector.webconnector.driver;
import java.io.IOException;

public class Homepage {
	webconnector wc=new webconnector();

    public void goToHomePage() throws InvalidFormatException, IOException{
		
		 String Actual=wc.getSpecificColumnData("./src/test/testdata/data.xlsx","sheet1", "Text"); 
		
		 
    	String Expected="selendroid-test-app";
    	Assert.assertEquals(Expected, Actual);
    	
      
    }

	
    public void verifyEnbutton() throws Exception{
		wc.PerformActionOnElement("ENLink_HomePage", "Click", "Element is clickable");
		 
   }
}