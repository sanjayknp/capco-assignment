package stepdefs;

import java.io.IOException;
import java.net.MalformedURLException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import ApplicationPages.Homepage;
import WebConnector.webconnector;
import io.cucumber.core.api.Scenario;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.BeforeStep;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class HomePageSteps extends webconnector {
    private Homepage homePage;
	private String scenDesc;

    public HomePageSteps() {
        this.homePage = new Homepage();
    }
    
    @Before
	public void before(Scenario scenario) throws Throwable {
		this.scenDesc = scenario.getName();
		setUpDriver();
	}
    
    @After
    public void after(Scenario scenario){
    	closeDriver(scenario);
    }
	
	@BeforeStep
	public void beforeStep() throws InterruptedException {
		Thread.sleep(2000);
	}

   /* @Given("^User navigates to HomePage$")
    public void UsernavigatestoHomePage() throws InvalidFormatException, IOException {
        this.homePage.goToHomePage();
    }

    @Then("^User verify that EN button is displayed$")
    public void UserverifythatENbuttonisdisplayed() throws Exception {
        this.homePage.verifyEnbutton();
    }*/
	 @Given("^User navigates to HomePage$")
	    public void user_navigates_to_homepage() throws Throwable {
		 
	        
	    }

	    @Given("^Create a list and add items$")
	    public void create_a_list_and_add_items() throws Throwable {
	        
	    }

	    @When("^Add new list items$")
	    public void add_new_list_items() throws Throwable {
	        
	    }

	    @When("^Sort the list$")
	    public void sort_the_list() throws Throwable {
	        
	    }

	    @Then("^Delete an item from the list$")
	    public void delete_an_item_from_the_list() throws Throwable {
	        
	    }

	    @Then("^validate the sorting of the list items$")
	    public void validate_the_sorting_of_the_list_items() throws Throwable {
	       
	    }
}
